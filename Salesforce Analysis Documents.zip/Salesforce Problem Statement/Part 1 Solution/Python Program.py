# -*- coding: utf-8 -*-
"""
Created on Sun Oct 17 13:58:29 2021
@author: Nikhil Sharma
"""

import pandas as pd
import numpy as np
import os

#Define the work directory and input data file
work_folder = r"C:\Users\RatedNik\Desktop\salesforce\data";
file=r"data_challenge_20210611_v2.xlsx";

#Reading file as a Pandas dataframe
data=pd.read_excel(os.path.join(work_folder,file),'Sheet1')

#Review file head
data.head()

#Dataset information. We don.t have any missing values
#50349 rows and 6 columns. All values are noon null
data.info()
data.shape

#Basic stats of the numberic vars
data.describe()

#Stats by account type
#Clearly more deviation and mean for SMB category compared to ENT
test1=data.groupby('Acct type').describe()

#Get Dummies - one hot encoding
data1=pd.get_dummies(data['Acct type'])
data2=pd.concat([data,data1],axis=1,join='inner')

#get month key - yymm format
data2['date'] = pd. to_datetime(data2['Date time'],format='%Y-%m-%d')
data2.sort_values(by=['Acct id','date'])
data2['year']=pd.DatetimeIndex(data2['date']).year
data2['month']=pd.DatetimeIndex(data2['date']).month
data2['month_key']=data2['year'].astype('str')+data2['month'].astype('str')

#There should be at max 4 month_key per account.
test_df=data2[['Acct id','month_key']].groupby('Acct id').nunique()
data2.columns =[column.replace(" ", "_") for column in data2.columns]
test_df1=data2.query('Acct_id=="SA10024"')

#GRoup data at month level.group by month key
data3=data2[['Acct_id','month_key','Activate_chat_bot','ENT','SMB','Number_of_clicks','Converted_to_paid_customer']]
data3_1=data3.groupby(['Acct_id','month_key'],as_index=False).sum()
data3_1.loc[data3_1['ENT'] >= 1,'ENT1'] = 1
data3_1.loc[data3_1['ENT'] < 1,'ENT1'] = 0
data3_1.loc[data3_1['SMB'] >= 1,'SMB1'] = 1
data3_1.loc[data3_1['SMB'] < 1,'SMB1'] = 0
data3_1.loc[data3_1['Converted_to_paid_customer'] >= 1,'Converted_to_paid_customer1'] = 1
data3_1.loc[data3_1['Converted_to_paid_customer'] < 1,'Converted_to_paid_customer1'] = 0

#Create month number indicator
data3_1['month_count'] = data3_1.groupby(['Acct_id']).cumcount()+1

#Data at account level.one row per account
data3_2=data3_1.pivot(index='Acct_id',columns='month_count', values='Number_of_clicks').add_prefix('click_').reset_index()
data3_3=data3_1[['Acct_id','ENT1','SMB1','Converted_to_paid_customer1']].drop_duplicates().reset_index()
data3_4=data3[['Acct_id','Activate_chat_bot']].drop_duplicates()
data3_5=pd.get_dummies(data3_4['Activate_chat_bot'])
data3_6=pd.concat([data3_4,data3_5],axis=1,join='inner')

#Merge data
data_final1=pd.merge(data3_3[['Acct_id','ENT1','SMB1','Converted_to_paid_customer1']],data3_6[['Acct_id','N','Y']],how='inner',on='Acct_id')
data_final2=pd.merge(data_final1,data3_2,how='inner',on='Acct_id')
data_final2.fillna(0,inplace=True)

#Final modeling data
data_final2['Monthclick2']=data_final2['click_1']+data_final2['click_2']
Model_data=data_final2[['Acct_id','ENT1','SMB1','Y','N','Monthclick2','Converted_to_paid_customer1']]

#Correlation
corr=Model_data.corr()
import seaborn as sns
sns.heatmap(corr, 
            xticklabels=corr.columns.values,
            yticklabels=corr.columns.values)

corr1=Model_data.groupby('ENT1').corr()

#Test Train SPlit
from sklearn.model_selection import train_test_split
X=Model_data[['ENT1','Y','Monthclick2']]  
y=Model_data['Converted_to_paid_customer1']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25)


'''
Lets try Random forest classifier on the input data and
look at results
'''

from sklearn.ensemble import RandomForestClassifier
RFC=RandomForestClassifier(n_estimators=85,bootstrap=True)
RFC.fit(X_train,y_train)

###Imprtance of variables per random forest
feature_imp =pd.Series(RFC.feature_importances_,index=X.columns).sort_values(ascending=False)
feature_imp

#Fit model
y_pred=RFC.predict(X_test)

#Import scikit-learn metrics module for accuracy calculation
from sklearn import metrics
# Model Accuracy, how often is the classifier correct?
print("Accuracy:",metrics.accuracy_score(y_test, y_pred)*100)
print("Recall:",metrics.recall_score(y_test, y_pred)*100)
print("Precission:",metrics.precision_score(y_test, y_pred)*100)
print("AUC Score:",metrics.roc_auc_score(y_test, y_pred)*100)
print("Confusion_Matrix:",metrics.confusion_matrix(y_test, y_pred))

pd.crosstab(y_test, y_pred, rownames = ['Actual'], colnames =['Predicted'], margins = True)
# Mean absolute difference
mad = np.abs(np.subtract.outer(y_test,y_pred)).mean()
# Relative mean absolute difference
rmad = mad/np.mean(y_test)
# Gini coefficient
g = 0.5 * rmad
print(g*100)

'''
In terms of precission and recall above model not doing good on test data
Lets also try XGBOOST classifier'''

from xgboost import XGBClassifier
# fit model no training data
model = XGBClassifier(n_estimators=100,learning_rate=0.1)
model.fit(X_train, y_train)

xgb_pred=RFC.predict(X_test)
print("Accuracy:",metrics.accuracy_score(y_test, xgb_pred)*100)
print("Recall:",metrics.recall_score(y_test, xgb_pred)*100)
print("Precission:",metrics.precision_score(y_test, xgb_pred)*100)
print("AUC Score:",metrics.roc_auc_score(y_test, xgb_pred)*100)
print("Confusion_Matrix:",metrics.confusion_matrix(y_test, xgb_pred))

''' 
No improvement as such on overall data.
Since we already know SMB has very less correlation with number of clicks.
Try to create classification  model only for ENT and 
look at results'''

MModel_data=Model_data.query('ENT1>0')

X=MModel_data[['Y','Monthclick2']]  
y=MModel_data['Converted_to_paid_customer1']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25)
RFC=RandomForestClassifier(n_estimators=85,bootstrap=True)
RFC.fit(X_train,y_train)

###Imprtance of variables per random forest
feature_imp =pd.Series(RFC.feature_importances_,index=X.columns).sort_values(ascending=False)
feature_imp

#Fit model
y_pred=RFC.predict(X_test)

# Model Accuracy, how often is the classifier correct?
print("Accuracy:",metrics.accuracy_score(y_test, y_pred)*100)
print("Recall:",metrics.recall_score(y_test, y_pred)*100)
print("Precission:",metrics.precision_score(y_test, y_pred)*100)
print("AUC Score:",metrics.roc_auc_score(y_test, y_pred)*100)
print("Confusion_Matrix:",metrics.confusion_matrix(y_test, y_pred))

pd.crosstab(y_test, y_pred, rownames = ['Actual'], colnames =['Predicted'], margins = True)



'''
Clearly improvement in the pricision and recall metrics this time.
Try exploring more details'''

t=data_final2.query('ENT1>0')
t['All']=t['click_1']+ t['click_2']+t['click_3']+t['click_4']
corr2=t.corr()


t['Monthclick2'].plot.hist()
t['Monthclick3']=np.log(t['Monthclick2'])
t['Monthclick3'].plot.hist()


#Distribution of clicks looks skewed. Lets try to investigate outliers
a=t['Monthclick3'].describe()
mean=t['Monthclick3'].mean()+(3*t['Monthclick3'].std())
mean1=t['Monthclick3'].mean()-(3*t['Monthclick3'].std())
print(mean1)

t.loc[t['Monthclick3'] <= mean1,'Monthclick3'] = mean1
t.loc[t['Monthclick3'] >= mean,'Monthclick3'] = mean

a=t.describe()
t['Monthclick3'].plot.hist()

X=t[['Y','Monthclick3']]  
y=t['Converted_to_paid_customer1']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25)
RFC=RandomForestClassifier(n_estimators=85,bootstrap=True)
RFC.fit(X_train,y_train)

###Imprtance of variables per random forest
feature_imp =pd.Series(RFC.feature_importances_,index=X.columns).sort_values(ascending=False)
feature_imp

#Fit model
y_pred=RFC.predict(X_test)

# Model Accuracy, how often is the classifier correct?
print("Accuracy:",metrics.accuracy_score(y_test, y_pred)*100)
print("Recall:",metrics.recall_score(y_test, y_pred)*100)
print("Precission:",metrics.precision_score(y_test, y_pred)*100)
print("AUC Score:",metrics.roc_auc_score(y_test, y_pred)*100)
print("Confusion_Matrix:",metrics.confusion_matrix(y_test, y_pred))











